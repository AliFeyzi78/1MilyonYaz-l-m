def sayHello(name):
    print('merhaba ' + name)

# sayHello('ali')
# sayHello('ahmet')
# sayHello('yağmur')
# sayHello('ada')


# def toplam(sayi1,sayi2):
#     return sayi1+sayi2

# a = toplam(10,20)
# b = toplam(20,20)
# c = toplam(30,25)

# print(a,b,c)

# def yasHesapla(dogumYili):
#     return 2020 - dogumYili

# yasAli = yasHesapla(1959)
# yasAhmet = yasHesapla(1980)
# yasYagmur = yasHesapla(1985)

# print(yasAli,yasAhmet,yasYagmur)

# def EmekliligeKacYilVar(dogumYili, isim):
#     yas = yasHesapla(dogumYili)
#     emeklilik = 65 - yas

#     if(emeklilik>0):
#         print(f'{isim}, emekliliğe {emeklilik} yıl kaldı')
#     else:
#         print('zaten emekli oldunuz.')

# EmekliligeKacYilVar(1959,'Ali')
# EmekliligeKacYilVar(1950,'Ahmet')
# EmekliligeKacYilVar(1980,'Arda')

# gönderilen bir kelimeyi adet kadar yazan fonksiyon.

# def yazdir(kelime,adet):
#     print(kelime*adet)

# yazdir('Merhaba\n', 10)

# def toplam(*params):
#     sonuc = 0

#     for a in params:
#         sonuc += a
    
#     print(sonuc)

# toplam(10,20,30)
# toplam(10,20,30,60,70)
# toplam(10,20,30,40)

def listeyeCevir(*params):
    liste = []

    for a in params:
        liste.append(a)

    return liste

print(listeyeCevir(10,20,30,'selam'))


