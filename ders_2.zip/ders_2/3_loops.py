# sayilar = [2,4,6,7,8,3,4,5,5]

# print(sayilar[0]) # 2
# print(sayilar[3]) # 7

# for a in sayilar:
#     print(a)

# isimler = ['sadık','çınar','yiğit','ada']

# for isim in isimler:
#     print(isim)

# isim = 'Sadık Turan'

# for a in isim:
#     print(a)

# sayilar = [(2,4),(6,7),(8,3),(4,5)]

# for a,b in sayilar:
#     print(a,b)

# d = {'k1':1,'k2':2,'k3':3}

# for key,value in d.items():
#     print(key,value)

sayilar = [2,4,6,7,8,3,4,5,5]

# hangi sayılar çift sayıdır?

# for i in sayilar:
#     if(i%2==0):
#         print(i)

# sayıların toplamı?
# toplam = 0

# for i in sayilar:
#     toplam += i

# print(toplam)

# tek sayıların karesini alınız.

# for i in sayilar:
#     if(i%2==1):
#         print(i**2)

# sehirler = ['istanbul','kocaeli','rize','izmir']

# for sehir in sehirler:
#     if (len(sehir)>4):
#         print(sehir)

urunler = [
    {
        'name':'samsung s6',
        'price':'3000'
    },
    {
        'name':'samsung s7',
        'price':'5000'
    },
    {
        'name':'samsung s8',
        'price':'6000'
    },
    {
        'name':'samsung s8',
        'price':'3000'
    }
]

# toplam = 0

# for urun in urunler:
#     fiyat = int(urun['price'])
#     toplam += fiyat

# print(f'ürün toplamı: {toplam}')

# for urun in urunler:
#     fiyat = int(urun['price'])
#     if(fiyat>=2000 and fiyat<=5000):
#         print(f"ürün adı: {urun['name']} fiyat: {urun['price']}")


# print(list())

# for i in range(0,101,2):
#     print(i)













