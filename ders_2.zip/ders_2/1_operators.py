# 1- Atama Operatörleri

# x = 5
# y = 10
# z = 20

# x, y, z = 2, 20, 30

# x += 5      # x = x + 5
# x -= 5      # x = x - 5
# x *= 5      # x = x * 5
# x /= 5      # x = x / 5
# x //= 5     # x = x // 5
# x **= 5     # x = x ** 5

# a,b, *sayilar = 10,20,30,40,50

# print(sayilar)
# print(a)

# print(type(sayilar))


# 2- Karşılaştırma Operatörleri

# username = 'sadikturan'
# password = '1234'

# _username = input('kullanıcı adınız: ')
# _password = input('parola: ')

# print(username==_username)
# print(password==_password)

x, y, z, k = 2, 20, 30, 20

sonuc = (x==y) # False
sonuc = (y==k) # True
sonuc = (y!=k) # False
sonuc = (y>=k) # True
sonuc = (x>y) # False
sonuc = (x>=y) # False
sonuc = (True == 1)
sonuc = (False == 0)
sonuc = True + False + 20

print(sonuc)

# 3- Mantıksal Operatörler

# and (ve)

# x = 4

# result = 5<x<10

# result = (x>5)     # False
# result = (x<10)    # True

# result = (x>5) and (x<10)

# False True  => False
# True True   => True
# False False => False


# hak = 2
# devam = 'e'

# result = (hak>0) and (devam=='e')

# print(result) # True


# or (veya)

# False True  => True
# True True   => True
# False False => False

# not (değil)
# x = 10
# result = not(x>5)


# x, 5-10 arasında olan bir çift sayı mı?

# x = 7

# result = (x>5) and (x<=10) # True
# result = (x%2==0)          # True

# result = ((x>5) and (x<=10)) and (x%2==0)

# print(result)

# Kullanıcıdan 2 vize (%60) ve final (%40) notunu alıp ortalama hesaplayınız.
#    Eğer ortalama 50 ve üstündeyse geçti değilse kaldı yazdırın.
#    a-) Ortamalama 50 olsa bile final notu en az 50 olmalıdır.
#    b-) Finalden 70 alındığında ortalamanın önemi olmasın.

vize1 = float(input('vize 1: '))
vize2 = float(input('vize 2: '))
final = float(input('final: '))

vizeToplam = vize1 + vize2
vizeOrtalama = vizeToplam / 2

ortalama = (vizeOrtalama * 0.6) + (final*0.4)

# basariDurumu = (ortalama>=50)
# basariDurumu = (ortalama>=50) and (final>=50)
basariDurumu = (ortalama>=50) or (final>=70)

print(f'ortalama: {ortalama} geçme durumu: {basariDurumu}')

