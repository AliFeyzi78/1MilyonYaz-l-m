# sayi = 130

# if((sayi>0) and (sayi<100)):
#     print('sayı 0-100 arasındadır.')
# else:
#     print('sayı 0-100 arasında değildir')


# sayi = int(input('sayı: '))

# if(sayi>0):
#     if (sayi%2==0):
#         print('sayı pozitif çift')
#     else:
#         print('sayı pozitif tek')
# else:
#     print('sayı negatif')


email = 'email@gmail.com'
password = '12345'

girilenEmail = input('email: ')
girilenPassword = input('parola: ')

if(girilenEmail != email):
    print('email yanlış')
elif (girilenPassword != password):
    print('parola yanlış')
else:
    print('giriş başarılı')


# if(girilenEmail == email):
#     if(girilenPassword == password):
#         print('giriş başarılı')
#     else:
#         print('parola yanlış')
# else:
#     print('email yanlış')
    
    
    
    







